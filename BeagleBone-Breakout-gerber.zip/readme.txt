Date : 12/21/2011 

README for gerber_bonebreakout_Dec21.zip

Files contained in the zip file:

README.1st     				This file
layer1_top   				Layer 1
layer2_gnd				Layer 2
layer3_pwr				Layer 3
layer4_bot				Layer 4
smask_top   				Soldermask Layer 1 Side (Component)
smask_bot    				Soldermask Layer 2 Side 
silk_top 				Silk Screen Layer 1 side
silk_bot 				Silk Screen Layer 2 side
fab	    				Fabrication Drawing Page 1(for Ref. ONLY)
assy_top	      			Assembly Drawing (for Ref. ONLY)
ncdrill-1-4.drl   			Drill tape, Layer 1 through 2
nc_param.txt 				Drill tape setup file
ncdrill.log    				Drill tape composite file (for Reference ONLY)
BONE_BREAKOUT_Dec21.ipc   		IPC-D-356 netlist (for Checking ONLY)
art_param.txt  				Artwork Format File (for Ref. ONLY)
placed_component.xls			Placement file for Assembly (for Ref. Only)
netlist_allegro.xls			Allegro Netlist (for Ref. Only)
BONE_BREAKOUT_Dec21_Allegro163.brd	File layout Allegro

Notes:	PLEASE REVIEW FAB DRAWING FOR SPECIFIC REQUIREMENTS.

